import RPi.GPIO as GPIO
import time
import Adafruit_DHT
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
led=21
led1=17
GPIO.setup(led,GPIO.OUT)
GPIO.setup(led1,GPIO.OUT)

GPIO.output(led,0)
GPIO.output(led1,0)
led=GPIO.PWM(21,50)
led1=GPIO.PWM(17,50)
temp=Adafruit_DHT.read_retry(11,2)

led.start(0)
led1.start(0)
print temp
pause_time=1
while 1:
   if temp>40:
	for i in range(0,51):
	 led.ChangeDutyCycle(i)
	 time.sleep(pause_time)	

	for i in range(50,-1,-1):
	 led.ChangeDutyCycle(i)
	 time.sleep(pause_time)	

   else:
	for i in range(0,51):
	 led1.ChangeDutyCycle(i)
	 time.sleep(pause_time)	

        for i in range(50,-1,-1):
	 led1.ChangeDutyCycle(i)
	 time.sleep(pause_time)	




