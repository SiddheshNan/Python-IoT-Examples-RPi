#Lighting a LED slowly with GPIO

import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(2,GPIO.OUT)
led=GPIO.PWM(2,50)
led.start(0)
pause_time=0.2

while True:
	for i in range(0,11):
		led.ChangeDutyCycle(i)
		time.sleep(pause_time)
	for i in range(10,-1,-1):
		led.ChangeDutyCycle(i)
		time.sleep(pause_time)
