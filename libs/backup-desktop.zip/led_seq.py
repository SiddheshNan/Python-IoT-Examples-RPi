import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
led=2
led1=14
led2=22
GPIO.setup(led,GPIO.OUT)
GPIO.setup(led1,GPIO.OUT)
GPIO.setup(led2,GPIO.OUT)
GPIO.output(led,0)
GPIO.output(led1,0)
GPIO.output(led2,0)
time.sleep(2)

while True:
	GPIO.output(led,1)
	time.sleep(5)
	GPIO.output(led,0)
	GPIO.output(led1,1)
	time.sleep(2)
	GPIO.output(led1,0)
	GPIO.output(led2,1)
	time.sleep(3)
	GPIO.output(led2,0)
