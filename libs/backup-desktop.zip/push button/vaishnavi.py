import RPi.GPIO as GPIO
import time

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
led=2
led1=14
led2=21
GPIO.setup(led.GPIO.OUT)
GPIO.setup(led.GPIO.IN)
GPIO.setup(2,GPIO.IN,pull_up_down=GPIO.pud_up)
time.sleep(2)

