import RPi.GPIO as GPIO
import time
GPIO.setmode (GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup (2,GPIO.OUT)
GPIO.setup (4,GPIO.IN)
GPIO.output(2,0)
GPIO.setup(2,GPIO.IN)


if(GPIO.input(4),1):

	GPIO.input(2,1)
	
	
