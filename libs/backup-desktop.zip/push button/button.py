import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)
#GPIO.setwarning(False)
led=2
GPIO.setup(led.GPIO.OUT)
GPIO.setup(led.GPIO.IN)
GPIO.setup(2,GPIO.IN,pull_up_down=GPIO.pud_up)
time.sleep(2)
