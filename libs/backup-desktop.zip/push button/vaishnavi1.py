import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
led=2
led1=14
led2=21
push=15
GPIO.setup(push,GPIO.IN)
GPIO.setup(led,GPIO.OUT)
GPIO.setup(led1,GPIO.OUT)
GPIO.setup(led2,GPIO.OUT)
GPIO.output(led,0)
GPIO.output(led1,0)
GPIO.output(led2,0)
while True:
    
    if GPIO.input(push)==0:
      GPIO.output(led,1)
      GPIO.output(led1,1)
      GPIO.output(led2,1)
      
    else:
      GPIO.output(led,0)
      GPIO.output(led1,0)
      GPIO.output(led2,0)
     
