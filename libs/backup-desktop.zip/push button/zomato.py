import RPi.GPIO as GPIO
import time
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(2,GPIO.OUT)
GPIO.setup(4,GPIO.IN,pull_up_down=GPIO.PUD_UP)
while True:
	btn_state=GPIO.input(4)
	if(btn_state==False):
		#GPIO.output(2,True)
		#while(btn_state==False):
			#GPIO.output(2,False)
	#else:
	#	GPIO.output(2,False)
		print("Button Pressed")
