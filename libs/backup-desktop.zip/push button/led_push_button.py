import RPi.GPIO as GPIO
import time
GPIO.setmode (GPIO.BCM)
GPIO.setwarnings(False)
led=2
gnd=3
GPIO.setup (led,GPIO.OUT)
GPIO.setup (gnd,GPIO.IN)
GPIO.output(led,0)

if(GPIO.input(gnd)):
	GPIO.output(led,1)
	time.sleep(60)
	
