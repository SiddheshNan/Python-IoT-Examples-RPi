import RPi.GPIO as GPIO
import time
GPIO.setmode (GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(10,GPIO.IN)
GPIO.setup(9,GPIO.OUT)
GPIO.input(10)

while True:
	GPIO.output(9,0)
		if(GPIO.input(10)==False):
			print("1")
			print(GPIO.input(10))
			time.sleep(2)
			
		
		else:
			print("Wait")
			GPIO.output(9,1)
		
		

