import RPi.GPIO as GPIO
import time
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
led=2
led1=14
led2=21
push=15
while True:
     GPIO.setup(push,GPIO.IN)
     if push == True:
      GPIO.setup(led,GPIO.OUT)
      for x in range(0):
           GPIO.output(led,1)
           time.sleep(5)

      GPIO.setup(led1,GPIO.OUT)
      for x in range(0):
           GPIO.output(led1,1)
           time.sleep(5)

      GPIO.setup(led2,GPIO.OUT)
      for x in range(0):
           GPIO.output(led2,1)
           time.sleep(5)
        
	   GPIO.output(2,GPIO.LOW)
           time.sleep(2)
     else:
	   GPIO.output(2,GPIO.HIGH)
           GPIO.output(14,GPIO.HIGH)
           GPIO.output(21,GPIO.HIGH)
     
