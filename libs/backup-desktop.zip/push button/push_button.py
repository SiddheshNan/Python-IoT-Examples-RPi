import RPi.GPIO as GPIO
import time
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
led=2
bu=3

GPIO.setmode(led,GPIO.OUT)
GPIO.setmode(bu,GPIO.IN)

GPIO.output(led,0)

if(GPIO.input(3)): 
	GPIO.output(led,1)
	time.sleep(2)

