import serial
usb = '/dev/ttyUSB1'
ser = serial.Serial(usb, 9600)
while True:
	mes=ser.readline()
	print mes
