import RPi.GPIO as GPIO
import time
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
led=2
led1=3
led2=4
while True:
	GPIO.setup(led,GPIO.OUT)
	for i in range (1):
		GPIO.output(led,1)
		time.sleep(5)
		GPIO.output(led,0)
		time.sleep(1)


	GPIO.setup(led1,GPIO.OUT)
	for i in range (1):
		GPIO.output(led1,1)
		time.sleep(3)
		GPIO.output(led1,0)
		time.sleep(1)

	GPIO.setup(led2,GPIO.OUT)
	for i in range (1):
		GPIO.output(led2,1)
		time.sleep(4)
		GPIO.output(led2,0)
		time.sleep(1)














