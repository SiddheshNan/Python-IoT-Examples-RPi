import Adafruit_DHT
from Adafruit_CharLCD import Adafruit_CharLCD
humidity,tempreture= Adafruit_DHT.read_retry(11,2)
lcd = Adafruit_CharLCD()
lcd.begin(16, 2)
lcd.setCursor(1, 0)
lcd.clear()
lcd.message(str(humidity))
lcd.message(str(tempreture))




