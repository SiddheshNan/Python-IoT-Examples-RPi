print 'helllo'

a = 3
b = 2


#print var+var2

for i in range(1,10):
    print i
