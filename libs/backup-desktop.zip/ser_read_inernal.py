import serial
usbport = '/dev/ttyUSB1'
ser = serial.Serial(usbport, 9600)
while True:
	mes=ser.readline()
	print mes
