import Adafruit_DHT
import RPi.GPIO as GPIO
hum, temp=Adafruit_DHT.read_retry(11,2)
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
r=16
g=26

GPIO.setup(r,GPIO.OUT)
GPIO.setup(g,GPIO.OUT)
GPIO.output(r,0)
GPIO.output(g,0)

if hum>50.0:
	GPIO.output(r,1)
else:
	GPIO.output(g,1)
print hum, temp
