import RPi.GPIO as GPIO
import time
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
led=2
while(True):
	GPIO.setup(led,GPIO.OUT)
	GPIO.output(led,1)
	time.sleep(1)
	GPIO.output(led,0)

