import RPi.GPIO as gp
import time
import tkinter as tk
class demo:
	def __init__(self,m):
		super().__init__(m)
                self.b=Button(text="ON", command=disp)
		self.b.grid(row=2,column=2)
	def disp():
		gp.setmode(gp.BCM)
		gp.setwarnings(False)
		LED1=2
		LED2=4
		LED3=27
		gp.setup(LED1,gp.OUT)
		gp.setup(LED2,gp.OUT)
		gp.setup(LED3,gp.OUT)

		for x in range(50):
			gp.output(LED1,1)
			time.sleep(1)
			gp.output(LED1,0)
		#	time.sleep(1)
			gp.output(LED2,1)
			time.sleep(1)
			gp.output(LED2,0)
			gp.output(LED3,1)
			time.sleep(1)
			gp.output(LED3,0)
top=Tk()
obj=demo(top)
top.mainloop()
