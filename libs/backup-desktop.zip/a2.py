import serial
usb='/dev/ttyUSB0'
ser=serial.Serial(usb,9600)
while True:
		d=raw_input('input data')
		while 0==0:	
			ser.write(d+'\n\r')



