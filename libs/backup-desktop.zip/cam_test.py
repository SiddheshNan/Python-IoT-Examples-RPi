import cv2
import imutils
webcam = cv2.VideoCapture(0)

while True:
	_, im = webcam.read()
	im = imutils.resize(im, width=800)
	cv2.imshow('OpenCV', im)
	if cv2.waitKey(1) & 0xFF == ord('q'):
		break
