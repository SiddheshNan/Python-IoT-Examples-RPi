import RPi.GPIO as GPIO
import time

import Adafruit_DHT
hum,temp=Adafruit_DHT.read_retry(11,2)
print hum,temp

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
led=10 #red
led1=9 #green
GPIO.setup(led,GPIO.OUT)
GPIO.setup(led1,GPIO.OUT)
GPIO.output(led,0)
GPIO.output(led1,0)

if hum>50:
	GPIO.output(led,1)
else:
	GPIO.output(led1,1)


