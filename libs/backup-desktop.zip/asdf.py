import RPi.GPIO as G
import time
G.setmode(G.BCM)
G.setwarnings(False)
r=2
y=4
g=26
G.setup(r,G.OUT)
G.setup(y,G.OUT)
G.setup(g,G.OUT)
G.output(r,0)
G.output(y,0)
G.output(g,0)
while True:
	G.output(r,1)
	time.sleep(0.5)
	G.output(r,0)
	G.output(y,1)
	time.sleep(0.5)
	G.output(y,0)
	G.output(g,1)
	time.sleep(0.5)
	G.output(g,0)
	



