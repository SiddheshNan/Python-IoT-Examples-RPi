from Adafruit_CharLCD import Adafruit_CharLCD
lcl = Adafruit_CharLCD()
lcl.begin(16, 2)
lcl.setCursor(1, 1)
lcl.message('hello')

