import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
led=2
button=26
GPIO.setup(led,GPIO.OUT)
GPIO.setup(button,GPIO.IN,pull_up_down=GPIO.PUD_UP)
while True:
	buttonstatus=GPIO.input(button)
	if buttonstatus==False:
		GPIO.output(led,1)
	else:
		GPIO.output(led,0)
	

