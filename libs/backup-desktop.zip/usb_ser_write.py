import serial
import time
usbport = '/dev/ttyUSB0'
ser = serial.Serial(usbport, 9600)
counter=0
while True:
	D= raw_input ("input data")
	ser.write ("write counter: %d \n" %(counter))
        time.sleep(5)
        counter+=1


