import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
led=2
button=18
GPIO.setup(led,GPIO.OUT)
GPIO.output(led,0)
GPIO.setup(18,GPIO.IN,pull_up_down=GPIO.PUD_UP)

while True:
	input_state = GPIO.input(18)
	if input_state == False:
			GPIO.output(led,0)
	
	
	

