import serial
usb='/dev/ttyAMA0'
ser=serial.Serial(usb,9600)
while True:
	d=raw_input('input data')
	ser.write(d+'\n\r')























